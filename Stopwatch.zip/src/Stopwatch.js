import React, { Component } from 'react';

class Stopwatch extends React.Component{
  state={
    runningtime:0,
    
  }; 
  handlestartclick=()=>
  { 
      this.timerId=setInterval(()=>{
        this.setState({runningtime:this.state.runningtime+1})
      },1000);
    

  }
  handlestopclick=()=>
  {
    clearInterval(this.timerId);
  }
  render(){
    return(
      <div>
      <h1>{this.state.runningtime}</h1>
      <button onClick={this.handlestartclick}>Start</button>
      <br/>
      <button onClick={this.handlestopclick}>Stop</button>

</div>
    )
  };

}
export default Stopwatch;