import React from "react";
import "./styles.css";

class App extends React.Component {
  state={
    count:0
  };
check=()=>{
  const t=this.state.count;
  this.setState({count:t+1})
}

  render() {
    return (
      <div>
      
        <p onClick={this.check}>This Is The Main Paragraph</p>
        <h2>You have Clicked the Paragraph :{this.state.count} times </h2>

      </div>
    );
  }
}
export default App;
